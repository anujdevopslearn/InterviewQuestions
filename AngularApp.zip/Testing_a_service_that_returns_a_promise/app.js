﻿var app = angular.module('myModule', []);

app.controller('MainCtrl', function ($scope, myService) {
    $scope.name = "Testing";
    $scope.temp = myService.myServiceData();
});

app.service('myService', function ($q) {
    this.myServiceData = function () {
        var deferred = $q.defer();
        return deferred.promise;
    }
});