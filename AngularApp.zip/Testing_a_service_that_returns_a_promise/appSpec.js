﻿describe('Unit Testing: MainCtrl', function () {
    var $scope = null;
    var ctrl = null;
    var mockMyService;
    var deferred;
    var $q;
    var data = { name: 'test' };
    var createController;

    beforeEach(module('myModule'));

    beforeEach(inject(function ($rootScope, $controller, $q) {
        $scope = $rootScope.$new();
        $q = $q;

        mockMyService = {
            myServiceData: function () { }
        };

        deferred = $q.defer();
        spyOn(mockMyService, 'myServiceData').and.returnValue(deferred.promise);

        createController = function () {
            return $controller('MainCtrl', {
                $scope: $scope,
                myService: mockMyService
            });
        };

    }));

    it('Should call myServiceData()', function () {
        var resolvedValue;

        ctrl = createController();

        $scope.temp.then(function (value) { resolvedValue = value; });

        deferred.resolve(data);
        $scope.$digest();

        expect(mockMyService.myServiceData).toHaveBeenCalled();
        expect(resolvedValue).toEqual(data);
    });
});